package br.com.itau.geradornotafiscal.core.domain.enums;

public enum RegimeTributacaoPJ {
    SIMPLES_NACIONAL,
    LUCRO_REAL,
    LUCRO_PRESUMIDO,
    OUTROS
}

