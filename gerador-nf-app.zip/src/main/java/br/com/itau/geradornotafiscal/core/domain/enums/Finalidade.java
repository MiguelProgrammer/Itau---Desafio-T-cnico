package br.com.itau.geradornotafiscal.core.domain.enums;

public enum Finalidade {
    COBRANCA_ENTREGA,
    ENTREGA,
    COBRANCA,
    OUTROS
}