package br.com.itau.geradornotafiscal.core.domain.enums;


public enum Regiao {
    NORTE,
    NORDESTE,
    CENTRO_OESTE,
    SUDESTE,
    SUL
}
