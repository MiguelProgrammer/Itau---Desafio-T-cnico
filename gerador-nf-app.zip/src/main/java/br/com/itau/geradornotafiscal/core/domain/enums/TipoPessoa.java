package br.com.itau.geradornotafiscal.core.domain.enums;

public enum TipoPessoa {
    FISICA,
    JURIDICA
}


